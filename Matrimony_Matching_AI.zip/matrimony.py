# Matrimony Matching System (Basic AI Logic)

profiles = [
    {"name": "Ravi", "age": 27, "religion": "Hindu", "education": "B.Tech"},
    {"name": "Aisha", "age": 25, "religion": "Muslim", "education": "MBA"},
    {"name": "Sneha", "age": 23, "religion": "Hindu", "education": "B.Tech"},
]

def match_user(preference):
    results = []
    for p in profiles:
        if (
            p["age"] <= preference["age"]
            and p["religion"] == preference["religion"]
            and p["education"] == preference["education"]
        ):
            results.append(p["name"])
    return results

user_pref = {"age": 26, "religion": "Hindu", "education": "B.Tech"}
matches = match_user(user_pref)
print("Matches found:", matches)
